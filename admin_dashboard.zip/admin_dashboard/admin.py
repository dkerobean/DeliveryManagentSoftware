from django.contrib import admin
from .models import DeliveryMultiplier


admin.site.register(DeliveryMultiplier)


